from flask import Flask, request, jsonify, render_template, send_from_directory
import logging

logging.basicConfig(
	filename='log/log_server.txt',
	level=logging.INFO,
	format='%(asctime)s - %(levelname)s - %(message)s'
)

import pickle
import os
os.environ["CRYPTOGRAPHY_OPENSSL_NO_LEGACY"] = "1"
from datetime import datetime,timedelta
import threading
import base64, hmac, hashlib
import time
from werkzeug.serving import make_server
from dotenv import load_dotenv
import google.generativeai as genai
from crypt import Crypt
from browser_request import br
import set

import json,uuid

def str_to_bool(s):
	try:
		return s.lower() in ['true', '1', 'yes', 'y', 'on']
	except:
		return False

app = Flask(__name__)

load_dotenv(dotenv_path='./.env')

with open("./.key", "r") as key_file:
	key = key_file.read()

encrypted_api_key = os.getenv("EAKEY")
KEY = Crypt.adv_xor_decrypt(encrypted_api_key, key)
genai.configure(api_key=KEY)
del KEY, encrypted_api_key

def ask_gemini(master,prompt):
	model = genai.GenerativeModel('gemini-2.0-flash')
	# Generate teks dengan prompt
	if master == "User":
		response = model.generate_content(str(set.instruction + prompt))
	elif master == "Admin":
		response = model.generate_content(prompt)
		
	return response.text
	
def save(path, data):
	with open(path, "wb") as file:
		pickle.dump(file,data)
		
def load(path):
	with open(path,"rb") as file:
		return pickle.load(path)

@app.before_request
def log_request():
	logging.info(f"{request.remote_addr} - {request.method} {request.path}")
	
""" ALL SERVER REQUEST HERE! """

@app.route("/")
def router_to_home():
	return render_template("index.html")

@app.route("/home")
def home():
	return render_template("home.html")
	
@app.route("/contact")
def contact():
	return render_template("contact.html")

#news section
@app.route("/news")
def news():
	return render_template("news.html")
	
@app.route("/api-router/news")
def api_news():
	return set.news_data

@app.route("/app")
def app_service():
	return render_template("service.html")

#login section
@app.route("/app/login")
def login():
	return render_template("login.html")
	
@app.route("/api-router/login/get", methods=["POST"])
def api_get_login():
	data = request.get_json()
	username = data.get("name", "")
	password = data.get("password", "")

	user_dir = f"data/user/{username}"
	pass_path = os.path.join(user_dir, "pass.bin")
	data_path = os.path.join(user_dir, "data.bin")

	if not os.path.exists(pass_path):
		return jsonify({"message": "Akun tidak ditemukan"}), 404

	try:
		with open(pass_path, "rb") as f:
			stored_password = Crypt.xor_decrypt(pickle.load(f), key.encode())
		if stored_password != password:
			return jsonify({"message": "Password salah"}), 401

		with open(data_path, "rb") as f:
			user_data = pickle.load(f)

		return jsonify({"message": "Login berhasil", "data": user_data}), 200

	except Exception as e:
		return jsonify({"message": "Terjadi kesalahan saat login", "error": str(e)}), 500

#signin section
@app.route("/app/signin")
def signin():
	return render_template("signin.html")
	
@app.route("/api-router/signin/get", methods=["POST"])
def api_get_signin():
	global key
	data = request.get_json()
	username = data.get("name", "")
	password = data.get("password", "")

	if not username or not password:
		return jsonify({"message": "Name dan password tidak boleh kosong"}), 400

	user_dir = f"data/user/{username}"
	pass_path = os.path.join(user_dir, "pass.bin")
	data_path = os.path.join(user_dir, "data.bin")
	

	# Cegah overwrite akun
	if os.path.exists(pass_path):
		return jsonify({"message": "Akun sudah terdaftar"}), 409

	try:
		os.makedirs(user_dir, exist_ok=True)

		# Simpan password
		with open(pass_path, "wb") as f:
			pickle.dump(Crypt.xor_crypt(password, key.encode()),f)

		# Simpan data awal user
		initial_data = {
			"name": username,
			"info": "",
			"uuid": str(uuid.uuid4())
		}
		print("done")
		with open(data_path, "wb") as f:
			pickle.dump(initial_data, f)

		return jsonify({"message": "Akun berhasil dibuat"}), 201

	except Exception as e:
		print(e)
		return jsonify({"message": "Gagal membuat akun", "error": str(e)}), 500
		
#gemini section
@app.route("/app/ask")
def ask_endpoint():
	return render_template("ask.html")
	
@app.route("/api-router/ask", methods=["POST"])
def api_ask():
	data = request.get_json()
	user = data.get('ask','')
	return jsonify({"response":ask_gemini("User", user)})
	
""" SERVER """

class ServerThread(threading.Thread):
	def __init__(self, app):
		threading.Thread.__init__(self)
		self.server = make_server(set.link, set.port, app)
		self.ctx = app.app_context()
		self.ctx.push()
		self.keep_running = True

	def run(self):
		print("Flask server dimulai...")
		while self.keep_running:
			self.server.handle_request()
		print("Flask server dimatikan.")

	def shutdown(self, command):
		import requests
	
		url = f"http://{set.link}:{set.port}/shutdown"
		data = {
			'nama': command[0] if len(command) > 0 else "",
			'pass': command[1] if len(command) > 1 else "",
			'pass_key': command[2] if len(command) > 2 else ""
		}
	
		try:
			r = requests.post(url, data=data)
			print("Server shutdown status:", r.status_code)
			print("Response:", r.text)
		except Exception as e:
			print("Shutdown request failed:", e)

@app.route('/shutdown', methods=['POST'])
def shutdown_route():
	try:
		print("get response")
		name = request.form.get('nama')
		password = request.form.get('pass')
		password2 = request.form.get('pass_key')

		if name != set.name or password != set.password or password2 != set.password2:
			print("err", name, password, password2)
			return "Unauthorized", 403

		global server
		if server:
			server.keep_running = False
			print("Shutdown flag set.")

		return "Shutdown dipanggil"

	except Exception as e:
		print("Exception in shutdown route:", e)
		return "Internal Server Error", 500


def shutdown_flask():
	func = request.environ.get('werkzeug.server.shutdown')
	if func:
		func()

# Terminal input handler
def terminal_input(server):
	time.sleep(1)
	run = 1
	br()
	while run:
		cmd = input(">> ").strip()
		cmd = cmd.split(" ")
		if cmd[0] == "stop":
			try:
				cmd = cmd[1:4]
				server.shutdown(cmd)
				run = 0
			except Exception:
				print("Error")
		elif cmd[0] == "ask":
			try:
				r = ask_gemini(cmd[1]," ".join(cmd[2:len(cmd)]))
				print(" ".join(cmd[2:len(cmd)]))
				
				r  = r.split("*////")
				for i in range(len(r)):
					r[i] = r[i].replace("\n","")
				print(r)
			except Exception as e:
				print("Error", e)
		elif cmd[0] == "browser":
			br()
		else:
			print("Perintah tidak dikenali.")

if __name__ == "__main__":
	global server
	server = ServerThread(app)
	server.start()
	terminal_input(server)
	server.join()