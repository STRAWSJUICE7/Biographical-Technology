from PIL import Image
import os

def convert_png_to_webp(source_folder, quality=80):
	for filename in os.listdir(source_folder):
		if filename.lower().endswith(".png"):
			img_path = os.path.join(source_folder, filename)
			img = Image.open(img_path).convert("RGBA")

			webp_filename = filename.rsplit('.', 1)[0] + ".webp"
			webp_path = os.path.join(source_folder, webp_filename)

			img.save(webp_path, "WEBP", quality=quality, method=6)  # method 6 = max compression
			print(f"✅ Converted: {filename} → {webp_filename}")

if __name__ == "__main__":
	folder = input("Masukkan folder gambar PNG: ").strip()
	convert_png_to_webp(folder)