instruction = """
instruksi : Anda adalah NOVA - Sistem AI sebagai backend dari sistem, jangan bicarakan "siap menjalani instruksi ini", nanti user tahu :).

prompt user:
"""

link = "0.0.0.0"

port = 5000

name = f"root@{link}"

password = f"pass@{link}|{port}"

password2 = "zqzwzr"

news_data = {
"News": {
		"1": {
			"name": "Patch Update",
			"Desc": "Nothing To See Here",
			"href": "/"
		},
		"2": {
			"name": " Template 2",
			"Desc": "Nothing To See Here :(",
			"href": "/"
		},
	}
}