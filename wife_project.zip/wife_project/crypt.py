class Crypt:
	@staticmethod
	def xor_crypt(data: str, key: bytes) -> str:
		data_bytes = data.encode()
		encrypted_bytes = bytearray()
		for i in range(len(data_bytes)):
			encrypted_bytes.append(data_bytes[i] ^ key[i % len(key)])
		return encrypted_bytes.hex()

	@staticmethod
	def xor_decrypt(hex_data: str, key: bytes) -> str:
		encrypted_bytes = bytearray.fromhex(hex_data)
		decrypted_bytes = bytearray()
		for i in range(len(encrypted_bytes)):
			decrypted_bytes.append(encrypted_bytes[i] ^ key[i % len(key)])
		return decrypted_bytes.decode()

	@staticmethod
	def base_int(data_key):
		base62 = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
		char_map = {char: i for i, char in enumerate(base62)}
		result = 0
		for c in data_key:
			if c not in char_map:
				raise ValueError(f"Invalid character: {c}")
			result = result * 62 + char_map[c]
		return result

	@staticmethod
	def generate_key(base62_iter="0"):
		base62 = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
		import random
		r = random.randint(round(len(base62) / 2), len(base62))
		result = str(len(base62_iter))
		for i in range(r):
			result += random.choice(base62)
			if i == round(r / 2 - 1):
				result += base62_iter
		return result

	@staticmethod
	def adv_xor_crypt(data: str, fullkey: str) -> str:
		# Cari angka pertama (panjang kode iterasi)
		for idx, ch in enumerate(fullkey):
			if ch.isdigit():
				iter_len = int(ch)
				iter_key = fullkey[idx + 1:idx + 1 + iter_len]
				break
		else:
			raise ValueError("No iteration length digit found in key.")

		iterations = Crypt.base_int(iter_key)
		# Ekstrak key byte dari fullkey (misalnya semua karakter setelah iter_key)
		key_start = idx + 1 + iter_len
		key_bytes = fullkey[key_start:].encode()

		# Iterasi XOR
		enc = data
		for _ in range(iterations):
			print(_)
			enc = Crypt.xor_crypt(enc, key_bytes)
		return enc

	@staticmethod
	def adv_xor_decrypt(hex_data: str, fullkey: str) -> str:
		for idx, ch in enumerate(fullkey):
			if ch.isdigit():
				iter_len = int(ch)
				iter_key = fullkey[idx + 1:idx + 1 + iter_len]
				break
		else:
			raise ValueError("No iteration length digit found in key.")

		iterations = Crypt.base_int(iter_key)
		key_start = idx + 1 + iter_len
		key_bytes = fullkey[key_start:].encode()

		dec = hex_data
		for _ in range(iterations):
			dec = Crypt.xor_decrypt(dec, key_bytes)
		return dec

def cr(x): return eval()

if __name__ == "__main__":
	print(Crypt.xor_crypt("hello","44772031".encode()))
