def br():
	from set import link, port
	url = str(link) +":"+ str(port)
	import webbrowser as wb
	wb.open("http://"+url)